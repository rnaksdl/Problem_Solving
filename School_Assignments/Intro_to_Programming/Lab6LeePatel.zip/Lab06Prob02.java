/* File: Lab06Prob03
 * Class: CSCI 1301
 * Author: Hari Patel and Kyumin Lee
 * Created: Feb 25, 2022
 * Last Modified: Feb 25,2022
 * Description: Make Aterisk upside down pyramid
 */
public class Lab06Prob02 {
	public static void main(String[] args) {
		// initialize variables
		int sum = 0;
		double value = 0;
		// make for loop
		for (int i = 5; i <= 250; i++) {
			value += Math.pow(((i * 2) + 1), 2);
		}
		// print results
		System.out.printf("The sum is %,.0f.", value);
	}
}
