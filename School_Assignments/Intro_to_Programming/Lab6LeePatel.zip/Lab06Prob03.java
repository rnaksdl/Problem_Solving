/* File: Lab06Prob03
 * Class: CSCI 1301
 * Author: Hari Patel and Kyumin Lee
 * Created: Feb 25, 2022
 * Last Modified: Feb 25,2022
 * Description: Make Aterisk upside down pyramid
 */
public class Lab06Prob03 {
	public static void main(String[] args) {
		int i, j;
		for (i = 5; i >= 0; i--) {
			for (j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
