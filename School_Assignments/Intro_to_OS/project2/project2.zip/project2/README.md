How to run my code
======================

A brief guidline to successfully run my code.

With zip file
--------------------------

Download and upzip the file there will be
project2.c, README.md, and Report.pdf
Opend the terminal and make sure that you are in the directory that my files are in.
then run

```
gcc project2.c -o project2
```

it will create project2 file with the output.
then run

```
./project2
```

to check the output

Through gpel
---------------------

make sure to be in gpel 8.
then run

```
/home/lee0436/project2
```

it will take you to my project2 directory.
there will be
project2, project2.c
you can check the output file right away by running

```
./project2
```

Or run the project2.c by running

```
gcc project2.c -o project2
```

then run

```
./project2
```