How to run my code
======================

A brief guidline to successfully run my code.

With zip file
--------------------------

Download and upzip the file there will be
project3.c, README.md, and Report.pdf
Opend the terminal and make sure that you are in the directory that my files are in.
then run

```
gcc project3.c -o project3 -lpthread -lrt
```

it will create project3 file with the output.
then run

```
./project3
```

to check the output

Through gpel
---------------------

make sure to be in gpel 8.
then run

```
/home/lee0436/project3
```

it will take you to my project2 directory.
there will be
project3, project3.c, mytest.dat
you can check the output file right away by running

```
./project3
```

Or run the project3.c by running

```
gcc project3.c -o project3 -lpthread -lrt
```

then run

```
./project3
```